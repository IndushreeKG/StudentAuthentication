package com.cg.StudentManagementApplication.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.StudentManagementApplication.model.Student;




@RestController
public class StudentController {
	
	Student student ;

	@RequestMapping(value = "/create", method = POST, produces =  APPLICATION_JSON_VALUE)

	public Student create(@RequestBody  Student student) {
		
		return student;
	}
	
	
	@RequestMapping(value = "/read", method = GET, produces =  APPLICATION_JSON_VALUE)
	public List<Student> readStudents() {
		return (List<Student>) student;
	}
	
	/*@RequestMapping(value = "/user-name", method = RequestMethod.GET)
    @ResponseBody
    public String currentUserName(Authentication authentication) {
        return authentication.getName();
    }
	@RequestMapping(value = "/admin-name", method = RequestMethod.GET)
    @ResponseBody
    public String currentUserName(Principal principal) {
        return principal.getName();
    }*/

/*	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public void modifyByID(Student customer,@RequestParam String custId, @RequestParam String name) {

		Student student = studentRepo.findByrollNo(rollNo);
		student.setName(name);
		studentRepo.save(student);

	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public void deleteByID(@RequestParam String name) {
		studentRepo.deleteByname(name);
	}*/
}
