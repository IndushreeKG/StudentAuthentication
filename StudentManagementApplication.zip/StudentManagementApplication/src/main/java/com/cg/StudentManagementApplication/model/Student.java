package com.cg.StudentManagementApplication.model;

public class Student {

	String name;
	String rollNo;
	String age;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Student(String name) {
		super();
		this.name = name;
	}


	public Student(String name, String rollNo, String age) {
		super();
		this.name = name;
		this.rollNo = rollNo;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
}
