package com.cg.StudentManagementApplication;

import junit.framework.TestCase;


/**
 * Unit test for simple App.
 */
public class AppTest   extends TestCase
{

    /**
     * Rigorous Test :-)
     */
    
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
